// 1. Importaciones
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const cors = require("cors");

// 2. Configuración del Servidor
const app = express();
const PUERTO = 3000;
app.use(express.json()); 
app.use(cors());

// 3. Configuración de la Base de Datos (Estilo Académico)
const conexion = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "finanzasBD"
});

// 4. Iniciar Servidor y Conexión a BD
app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto: ${PUERTO}`);
});

conexion.connect(error => {
    if (error) return console.error("Error al conectar a la BD:", error.message);
    console.log("Conexión exitosa a la base de datos");
});

// ===============================================
// ===          ENDPOINTS DE LA API            ===
// ===============================================

// Endpoint de prueba
app.get("/", (req, res) => {
    res.send("Bienvenido a mi API Web Service para Finanzas");
});


// --- RUTAS DE AUTENTICACIÓN ---

// Registrar un nuevo usuario
app.post("/usuario/registrar", (req, res) => {
    const { correo_usuario, password } = req.body;
    if (!correo_usuario || !password) {
        return res.status(400).json({ mensaje: "El correo y la contraseña son obligatorios." });
    }
    
    bcrypt.hash(password, 10, (err, password_hash) => {
        if (err) return res.status(500).json({ mensaje: "Error al hashear la contraseña." });

        const query = 'INSERT INTO usuarios (correo_usuario, password_hash) VALUES (?, ?)';
        conexion.query(query, [correo_usuario, password_hash], (error, resultado) => {
            if (error) {
                if (error.code === 'ER_DUP_ENTRY') {
                    return res.status(409).json({ mensaje: "Este correo electrónico ya está registrado." });
                }
                return res.status(500).json({ mensaje: "Error en el servidor al registrar el usuario." });
            }

            // CORRECCIÓN CLAVE: La respuesta debe coincidir con los modelos de Android.
            const nuevoUsuario = {
                id_usuario: resultado.insertId,
                correo_usuario: correo_usuario
            };
            res.status(201).json({ 
                mensaje: "Usuario registrado con éxito.", 
                usuario: nuevoUsuario 
            });
        });
    });
});

// Iniciar sesión de un usuario
app.post("/usuario/login", (req, res) => {
    const { correo_usuario, password } = req.body;
    if (!correo_usuario || !password) {
        return res.status(400).json({ mensaje: "El correo y la contraseña son obligatorios." });
    }
    
    const query = 'SELECT * FROM usuarios WHERE correo_usuario = ?';
    conexion.query(query, [correo_usuario], (error, usuarios) => {
        if (error || usuarios.length === 0) {
            return res.status(401).json({ mensaje: "Credenciales incorrectas." });
        }
        
        const usuario = usuarios[0];
        bcrypt.compare(password, usuario.password_hash, (err, esValido) => {
            if (err || !esValido) {
                return res.status(401).json({ mensaje: "Credenciales incorrectas." });
            }
            
            const usuarioParaEnviar = {
                id_usuario: usuario.id_usuario,
                correo_usuario: usuario.correo_usuario
            };
            res.status(200).json({ mensaje: "Login exitoso.", usuario: usuarioParaEnviar });
        });
    });
});


// --- RUTAS DE CUENTAS ---

// Crear la primera cuenta de un usuario (flujo de onboarding)
app.post('/cuenta/crear', (req, res) => {
    // --- CAMBIO CLAVE: Añadimos 'img_cuenta' a la desestructuración ---
    const { id_usuario, nombre_cuenta, saldo_actual, moneda, img_cuenta } = req.body;

    if (id_usuario === undefined || !nombre_cuenta || saldo_actual === undefined || !moneda) {
        return res.status(400).json({ mensaje: 'Faltan datos obligatorios para crear la cuenta.' });
    }

    // --- CAMBIO CLAVE: Añadimos la columna y el valor a la consulta ---
    const query = 'INSERT INTO cuentas (id_usuario, nombre_cuenta, saldo_actual, moneda, img_cuenta) VALUES (?, ?, ?, ?, ?)';
    // El valor de img_cuenta puede ser null si el usuario no elige uno.
    conexion.query(query, [id_usuario, nombre_cuenta, saldo_actual, moneda, img_cuenta || null], (error, resultado) => {
        if (error) {
            console.error("Error en INSERT de cuenta:", error.message); 
            return res.status(500).json({ mensaje: 'Error de base de datos al crear la cuenta.' });
        }
        res.status(201).json({ mensaje: 'Cuenta creada con éxito', id_cuenta: resultado.insertId });
    });
});

// --- RUTAS DE CATEGORÍAS ---

// Crear una categoría personalizada
app.post('/categoria/agregar', (req, res) => {
    const { id_usuario, nombre_categoria, tipo_categoria, img_categoria } = req.body;
    if (id_usuario === undefined || !nombre_categoria || !tipo_categoria) {
        return res.status(400).json({ mensaje: 'Faltan datos para crear la categoría.' });
    }
    const query = 'INSERT INTO categorias (id_usuario, nombre_categoria, tipo_categoria, img_categoria) VALUES (?, ?, ?, ?)';
    conexion.query(query, [id_usuario, nombre_categoria, tipo_categoria, img_categoria], (error, resultado) => {
        if (error) return res.status(500).json({ mensaje: 'Error al crear la categoría.' });
        res.status(201).json({ mensaje: 'Categoría creada con éxito', id_categoria: resultado.insertId });
    });
});

// Obtener categorías (por defecto y del usuario) por tipo
app.get('/categorias/:idUsuario', (req, res) => {
    const { idUsuario } = req.params;
    const { tipo } = req.query; 

    if (!tipo) return res.status(400).json({ mensaje: "El parámetro 'tipo' es obligatorio." });

    const query = 'SELECT * FROM categorias WHERE (id_usuario = ? OR id_usuario IS NULL) AND tipo_categoria = ?';
    conexion.query(query, [idUsuario, tipo], (error, rpta) => {
        if (error) return res.status(500).json({ mensaje: "Error al obtener las categorías." });
        res.json({ listaCategorias: rpta });
    });
});

// OBTENER DETALLES DE UNA SOLA CATEGORÍA
app.get("/categorias/detalle/:id", (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM categorias WHERE id_categoria = ?';
    conexion.query(query, [id], (error, resultados) => {
        if (error) {
            return res.status(500).json({ mensaje: "Error al obtener los detalles de la categoría." });
        }
        if (resultados.length === 0) {
            return res.status(404).json({ mensaje: "Categoría no encontrada." });
        }
        // Devolvemos el primer (y único) resultado. No lo envolvemos en un objeto.
        res.status(200).json(resultados[0]);
    });
});

// ACTUALIZAR UNA CATEGORÍA PERSONALIZADA
app.put("/categoria/actualizar/:id", (req, res) => {
    const { id } = req.params;
    // Solo permitimos cambiar el nombre y el ícono.
    const { nombre_categoria, img_categoria } = req.body;

    if (!nombre_categoria || !img_categoria) {
        return res.status(400).json({ mensaje: "Faltan datos para actualizar." });
    }

    const query = 'UPDATE categorias SET nombre_categoria = ?, img_categoria = ? WHERE id_categoria = ?';
    conexion.query(query, [nombre_categoria, img_categoria, id], (error, resultado) => {
        if (error) return res.status(500).json({ mensaje: "Error al actualizar la categoría." });
        if (resultado.affectedRows === 0) return res.status(404).json({ mensaje: "Categoría no encontrada." });
        res.status(200).json({ mensaje: "Categoría actualizada con éxito." });
    });
});

// ELIMINAR UNA CATEGORÍA PERSONALIZADA
app.delete("/categoria/eliminar/:id", (req, res) => {
    const { id } = req.params;

    // IMPORTANTE: Nos aseguramos de que solo se puedan borrar categorías con un id_usuario.
    const query = 'DELETE FROM categorias WHERE id_categoria = ? AND id_usuario IS NOT NULL';
    conexion.query(query, [id], (error, resultado) => {
        if (error) {
            // Este error específico ('ER_ROW_IS_REFERENCED_2') ocurre si una transacción aún usa esta categoría.
            if (error.code === 'ER_ROW_IS_REFERENCED_2') {
                return res.status(409).json({ mensaje: "No se puede eliminar. Hay transacciones usando esta categoría." });
            }
            return res.status(500).json({ mensaje: "Error de base de datos al eliminar." });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensaje: "Categoría no encontrada o es una categoría por defecto que no se puede eliminar." });
        }
        res.status(200).json({ mensaje: "Categoría eliminada con éxito." });
    });
});

// --- RUTAS DE TRANSACCIONES ---

// Obtener todas las transacciones de una cuenta
app.get("/transacciones/:idCuenta", (req, res) => {
    const { idCuenta } = req.params;
    const query = `
        SELECT t.*, c.nombre_categoria, c.tipo_categoria, c.img_categoria
        FROM transacciones t
        JOIN categorias c ON t.id_categoria = c.id_categoria
        WHERE t.id_cuenta = ?
        ORDER BY t.fecha_transaccion DESC
    `;
    conexion.query(query, [idCuenta], (error, rpta) => {
        if (error) return res.status(500).json({ mensaje: "Error al obtener las transacciones." });
        res.json({ listaTransacciones: rpta });
    });
});

// Añadir una nueva transacción
app.post("/transaccion/agregar", (req, res) => {
    const { id_cuenta, id_categoria, monto_transaccion, descripcion, fecha_transaccion } = req.body;
    if (!id_cuenta || !id_categoria || monto_transaccion === undefined || !fecha_transaccion) {
        return res.status(400).json({ mensaje: "Faltan datos obligatorios." });
    }

    conexion.query('SELECT tipo_categoria FROM categorias WHERE id_categoria = ?', [id_categoria], (error, categorias) => {
        if (error || categorias.length === 0) {
            return res.status(404).json({ mensaje: "La categoría especificada no existe." });
        }
        
        const tipo = categorias[0].tipo_categoria;
        
        const transaccionData = { id_cuenta, id_categoria, monto_transaccion, descripcion, fecha_transaccion };
        const insertQuery = 'INSERT INTO transacciones SET ?';
        conexion.query(insertQuery, transaccionData, (error) => {
            if (error) return res.status(500).json({ mensaje: "Error al registrar la transacción." });
            
            const montoAjustado = tipo === 'ingreso' ? parseFloat(monto_transaccion) : -parseFloat(monto_transaccion);
            const updateQuery = 'UPDATE cuentas SET saldo_actual = saldo_actual + ? WHERE id_cuenta = ?';
            
            conexion.query(updateQuery, [montoAjustado, id_cuenta], (error) => {
                if (error) return res.status(500).json({ mensaje: "Error al actualizar el saldo de la cuenta." });
                res.status(201).json({ mensaje: 'Transacción registrada y saldo actualizado con éxito' });
            });
        });
    });
});


// --- RUTAS DE GESTIÓN DE PERFIL ---

// Modificar la contraseña del usuario
app.post("/usuario/modificar_contrasena", (req, res) => {
    const { id_usuario, nueva_contrasena } = req.body;
    if (!id_usuario || !nueva_contrasena) {
        return res.status(400).json({ mensaje: "ID de usuario y nueva contraseña son obligatorios." });
    }

    bcrypt.hash(nueva_contrasena, 10, (err, password_hash) => {
        if (err) return res.status(500).json({ mensaje: "Error al hashear la nueva contraseña." });

        const query = 'UPDATE usuarios SET password_hash = ? WHERE id_usuario = ?';
        conexion.query(query, [password_hash, id_usuario], (error, resultado) => {
            if (error) return res.status(500).json({ mensaje: "Error al actualizar la contraseña." });
            if (resultado.affectedRows === 0) return res.status(404).json({ mensaje: "Usuario no encontrado." });
            res.status(200).json({ mensaje: "Contraseña actualizada con éxito." });
        });
    });
});

// Eliminar un usuario y todos sus datos asociados
app.delete("/usuario/eliminar/:id", (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM usuarios WHERE id_usuario = ?';
// En index.js, en el endpoint DELETE /usuario/eliminar/:id
    conexion.query(query, [id], (error, resultado) => {
        if (error) {
            console.error("Error al intentar eliminar usuario ID:", id, error.message); // Loguear el error
            return res.status(500).json({ mensaje: "Error al eliminar el usuario." });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensaje: "Usuario no encontrado para eliminar." });
        }
        // Loguear el éxito
        console.log(`Usuario con ID: ${id} ha sido eliminado exitosamente.`);
        res.status(200).json({ mensaje: "Usuario eliminado con éxito." });
    });
});

// -- TRANSACCIÓNES --
// OBTENER DETALLES DE UNA SOLA TRANSACCIÓN
app.get("/transaccion/:id", (req, res) => {
    const { id } = req.params;
    const query = `
        SELECT t.*, c.nombre_categoria, c.tipo_categoria, c.img_categoria, cu.nombre_cuenta, cu.moneda
        FROM transacciones t
        JOIN categorias c ON t.id_categoria = c.id_categoria
        JOIN cuentas cu ON t.id_cuenta = cu.id_cuenta
        WHERE t.id_transaccion = ?
    `;
    conexion.query(query, [id], (error, resultados) => {
        if (error) {
            return res.status(500).json({ mensaje: "Error al obtener los detalles de la transacción." });
        }
        if (resultados.length === 0) {
            return res.status(404).json({ mensaje: "Transacción no encontrada." });
        }
        // Devolvemos el primer (y único) resultado. No lo envolvemos en un objeto.
        res.status(200).json(resultados[0]);
    });
});


// ELIMINAR UNA TRANSACCIÓN Y RESTAURAR EL SALDO
app.delete("/transaccion/eliminar/:id", (req, res) => {
    const { id } = req.params;

    // Paso 1: Obtener la transacción que vamos a eliminar para saber su monto, tipo y cuenta.
    const selectQuery = 'SELECT t.*, c.tipo_categoria FROM transacciones t JOIN categorias c ON t.id_categoria = c.id_categoria WHERE id_transaccion = ?';
    conexion.query(selectQuery, [id], (error, transacciones) => {
        if (error) return res.status(500).json({ mensaje: "Error al buscar la transacción a eliminar." });
        if (transacciones.length === 0) return res.status(404).json({ mensaje: "La transacción no existe." });
        
        const transaccion = transacciones[0];
        const monto = transaccion.monto_transaccion;
        const tipo = transaccion.tipo_categoria;
        const id_cuenta = transaccion.id_cuenta;

        // Paso 2: Si la encontramos, procedemos a eliminarla.
        const deleteQuery = 'DELETE FROM transacciones WHERE id_transaccion = ?';
        conexion.query(deleteQuery, [id], (error) => {
            if (error) return res.status(500).json({ mensaje: "Error al eliminar la transacción." });

            // Paso 3: Si la eliminación fue exitosa, revertimos el saldo en la cuenta.
            // Si era un gasto, sumamos el monto de vuelta. Si era un ingreso, lo restamos.
            const montoARevertir = tipo === 'gasto' ? parseFloat(monto) : -parseFloat(monto);
            const updateQuery = 'UPDATE cuentas SET saldo_actual = saldo_actual + ? WHERE id_cuenta = ?';

            conexion.query(updateQuery, [montoARevertir, id_cuenta], (error) => {
                if (error) return res.status(500).json({ mensaje: "Error al restaurar el saldo de la cuenta." });
                
                res.status(200).json({ mensaje: 'Transacción eliminada y saldo restaurado con éxito' });
            });
        });
    });
});

app.get("/transacciones/usuario/:idUsuario", (req, res) => {
    const { idUsuario } = req.params;
    // La consulta busca todas las transacciones de todas las cuentas que pertenecen al usuario.
    const query = `
        SELECT t.*, c.nombre_categoria, c.tipo_categoria, c.img_categoria
        FROM transacciones t
        JOIN categorias c ON t.id_categoria = c.id_categoria
        JOIN cuentas cu ON t.id_cuenta = cu.id_cuenta
        WHERE cu.id_usuario = ?
        ORDER BY t.fecha_transaccion DESC
    `;
    conexion.query(query, [idUsuario], (error, rpta) => {
        if (error) {
            console.error("Error al obtener transacciones de usuario:", error.message);
            return res.status(500).json({ mensaje: "Error al obtener las transacciones." });
        }
        // Envolvemos la respuesta como lo espera Android
        res.json({ listaTransacciones: rpta });
    });
});

// ACTUALIZAR UNA CUENTA EXISTENTE
app.put("/cuenta/actualizar/:id", (req, res) => {
    const { id } = req.params;
    const { nombre_cuenta, saldo_actual } = req.body; // Asumimos que solo se puede editar el nombre y el saldo

    if (!nombre_cuenta || saldo_actual === undefined) {
        return res.status(400).json({ mensaje: "Faltan datos para actualizar la cuenta." });
    }

    const query = 'UPDATE cuentas SET nombre_cuenta = ?, saldo_actual = ? WHERE id_cuenta = ?';
    conexion.query(query, [nombre_cuenta, saldo_actual, id], (error, resultado) => {
        if (error) {
            console.error("Error al actualizar cuenta:", error.message);
            return res.status(500).json({ mensaje: "Error de base de datos al actualizar." });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensaje: "Cuenta no encontrada." });
        }
        res.status(200).json({ mensaje: "Cuenta actualizada con éxito." });
    });
});

// ELIMINAR UNA CUENTA
app.delete("/cuenta/eliminar/:id", (req, res) => {
    const { id } = req.params;

    // Gracias a "ON DELETE CASCADE" en la tabla 'transacciones', al eliminar una cuenta,
    // todas sus transacciones asociadas se eliminarán automáticamente. ¡Muy eficiente!
    const query = 'DELETE FROM cuentas WHERE id_cuenta = ?';
    conexion.query(query, [id], (error, resultado) => {
        if (error) {
            console.error("Error al eliminar cuenta:", error.message);
            return res.status(500).json({ mensaje: "Error de base de datos al eliminar." });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensaje: "Cuenta no encontrada para eliminar." });
        }
        res.status(200).json({ mensaje: "Cuenta eliminada con éxito." });
    });
});

app.get("/cuentas/detalle/:id", (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM cuentas WHERE id_cuenta = ?';
    conexion.query(query, [id], (error, resultados) => {
        if (error) return res.status(500).json({ mensaje: "Error al obtener la cuenta." });
        if (resultados.length === 0) return res.status(404).json({ mensaje: "Cuenta no encontrada." });
        res.status(200).json(resultados[0]);
    });
});

// Obtener todas las cuentas de un usuario
app.get("/cuentas/:idUsuario", (req, res) => {
    const { idUsuario } = req.params;
    const query = 'SELECT * FROM cuentas WHERE id_usuario = ?';
    conexion.query(query, [idUsuario], (error, rpta) => {
        if (error) return res.status(500).json({ mensaje: "Error al obtener las cuentas." });
        res.json({ listaCuentas: rpta });
    });
});


// --- Reemplaza este endpoint en tu index.js ---

app.post("/cuenta/transferencia", (req, res) => {
    // 1. OBTENEMOS TODOS LOS DATOS, INCLUYENDO LOS NUEVOS
    const { id_usuario, id_cuenta_origen, id_cuenta_destino, monto, comentario, fecha_transferencia } = req.body;

    // 2. VALIDACIONES
    // La validación ahora solo comprueba los campos estrictamente necesarios.
    // 'comentario' es opcional y 'fecha_transferencia' tendrá un valor por defecto.
    if (!id_usuario || !id_cuenta_origen || !id_cuenta_destino || !monto || monto <= 0) {
        return res.status(400).json({ mensaje: "Faltan datos o el monto es inválido." });
    }
    if (id_cuenta_origen === id_cuenta_destino) {
        return res.status(400).json({ mensaje: "Las cuentas de origen y destino no pueden ser la misma." });
    }

    // 3. ACTUALIZAR CUENTA DE ORIGEN (RESTAR SALDO)
    const queryOrigen = 'UPDATE cuentas SET saldo_actual = saldo_actual - ? WHERE id_cuenta = ? AND saldo_actual >= ?';
    conexion.query(queryOrigen, [monto, id_cuenta_origen, monto], (error, resultadoOrigen) => {
        if (error) return res.status(500).json({ mensaje: "Error al procesar la cuenta de origen." });
        if (resultadoOrigen.affectedRows === 0) {
            return res.status(400).json({ mensaje: "Saldo insuficiente o cuenta de origen no encontrada." });
        }

        // 4. ACTUALIZAR CUENTA DE DESTINO (SUMAR SALDO)
        const queryDestino = 'UPDATE cuentas SET saldo_actual = saldo_actual + ? WHERE id_cuenta = ?';
        conexion.query(queryDestino, [monto, id_cuenta_destino], (error, resultadoDestino) => {
            if (error || resultadoDestino.affectedRows === 0) {
                // Si esto falla, revertimos el débito de la cuenta de origen para mantener la consistencia.
                const queryRevertir = 'UPDATE cuentas SET saldo_actual = saldo_actual + ? WHERE id_cuenta = ?';
                conexion.query(queryRevertir, [monto, id_cuenta_origen], () => {
                    console.error("Error crítico: La transferencia falló en el destino. Se ha intentado revertir el saldo de origen.");
                });
                return res.status(500).json({ mensaje: "Error al procesar la cuenta de destino." });
            }

            // 5. REGISTRAR EN EL HISTORIAL (CON LOS NUEVOS DATOS)
            // Si el frontend no envía una fecha, usamos la fecha y hora actual del servidor.
            const fechaParaGuardar = fecha_transferencia ? new Date(fecha_transferencia) : new Date();

            const historialQuery = 'INSERT INTO historial_transferencias (id_usuario, id_cuenta_origen, id_cuenta_destino, monto, comentario, fecha_transferencia_realizada) VALUES (?, ?, ?, ?, ?, ?)';
            // Pasamos todos los parámetros en el orden correcto.
            conexion.query(historialQuery, [id_usuario, id_cuenta_origen, id_cuenta_destino, monto, comentario, fechaParaGuardar], (error) => {
                if (error) {
                    console.error("Advertencia: La transferencia monetaria se completó, pero no se pudo registrar en el historial.", error.message);
                }
                res.status(200).json({ mensaje: "Transferencia realizada con éxito." });
            });
        });
    });
});

// --- Reemplaza este endpoint en tu index.js ---

app.get("/transferencias/historial/:idUsuario", (req, res) => {
    const { idUsuario } = req.params;

    // La consulta ahora une con la tabla usuarios para obtener el nombre de la moneda, si es necesario en el futuro.
    // Y lo más importante, ordena por la columna correcta.
    const query = `
        SELECT 
            h.*, 
            origen.nombre_cuenta AS nombre_origen, 
            destino.nombre_cuenta AS nombre_destino,
            origen.moneda 
        FROM historial_transferencias h
        JOIN cuentas origen ON h.id_cuenta_origen = origen.id_cuenta
        JOIN cuentas destino ON h.id_cuenta_destino = destino.id_cuenta
        WHERE h.id_usuario = ?
        ORDER BY h.fecha_transferencia_realizada DESC  -- <-- AQUÍ ESTÁ LA CORRECCIÓN
    `;
    conexion.query(query, [idUsuario], (error, resultados) => {
        if (error) {
            console.error("Error en la consulta del historial:", error.message); // Logueamos el error para verlo en la terminal
            return res.status(500).json({ mensaje: "Error al obtener el historial." });
        }
        res.status(200).json({ historial: resultados });
    });
});

// OBTENER DETALLES DE UNA TRANSFERENCIA ESPECÍFICA
app.get("/transferencia/detalle/:id", (req, res) => {
    const { id } = req.params;
    const query = `
        SELECT 
            h.*, 
            origen.nombre_cuenta AS nombre_origen, 
            destino.nombre_cuenta AS nombre_destino
        FROM historial_transferencias h
        JOIN cuentas origen ON h.id_cuenta_origen = origen.id_cuenta
        JOIN cuentas destino ON h.id_cuenta_destino = destino.id_cuenta
        WHERE h.id_historial = ?
    `;
    conexion.query(query, [id], (error, resultados) => {
        if (error) return res.status(500).json({ mensaje: "Error al obtener el detalle." });
        if (resultados.length === 0) return res.status(404).json({ mensaje: "Transferencia no encontrada." });
        // Devolvemos el primer (y único) resultado.
        res.status(200).json(resultados[0]);
    });
});

// ELIMINAR UN REGISTRO DEL HISTORIAL Y REVERTIR LA TRANSFERENCIA
app.delete("/transferencia/eliminar/:id", (req, res) => {
    const { id } = req.params;

    // 1. Obtener los datos de la transferencia a eliminar.
    const selectQuery = 'SELECT * FROM historial_transferencias WHERE id_historial = ?';
    conexion.query(selectQuery, [id], (error, historiales) => {
        if (error) return res.status(500).json({ mensaje: "Error al buscar la transferencia." });
        if (historiales.length === 0) return res.status(404).json({ mensaje: "Registro de historial no encontrado." });

        const historial = historiales[0];
        const monto = historial.monto;
        const id_cuenta_origen = historial.id_cuenta_origen;
        const id_cuenta_destino = historial.id_cuenta_destino;

        // 2. Revertir el dinero: Sumar al origen y restar al destino.
        const queryRevertirOrigen = 'UPDATE cuentas SET saldo_actual = saldo_actual + ? WHERE id_cuenta = ?';
        conexion.query(queryRevertirOrigen, [monto, id_cuenta_origen], (error, resultadoOrigen) => {
            if (error || resultadoOrigen.affectedRows === 0) return res.status(500).json({ mensaje: "Error al revertir saldo en cuenta de origen." });

            const queryRevertirDestino = 'UPDATE cuentas SET saldo_actual = saldo_actual - ? WHERE id_cuenta = ?';
            conexion.query(queryRevertirDestino, [monto, id_cuenta_destino], (error, resultadoDestino) => {
                if (error || resultadoDestino.affectedRows === 0) {
                     // Si esto falla, el estado es inconsistente. Logueamos para revisión manual.
                    console.error("ERROR CRÍTICO: El saldo se devolvió al origen pero no se pudo restar del destino.");
                    return res.status(500).json({ mensaje: "Error al revertir saldo en cuenta de destino." });
                }

                // 3. Si ambos saldos se revirtieron, eliminamos el registro del historial.
                const deleteQuery = 'DELETE FROM historial_transferencias WHERE id_historial = ?';
                conexion.query(deleteQuery, [id], (error) => {
                    if (error) return res.status(500).json({ mensaje: "Saldos revertidos, pero error al eliminar el registro del historial." });

                    res.status(200).json({ mensaje: "Transferencia eliminada y saldos restaurados." });
                });
            });
        });
    });
});


app.get("/estadisticas/resumen_periodo/:idUsuario", (req, res) => {
    const { idUsuario } = req.params;
    const { periodo } = req.query; // 'dia', 'semana', 'mes', 'año'

    let groupByFormat;
    switch (periodo) {
        case 'dia':
            groupByFormat = '%Y-%m-%d'; // Agrupar por día
            break;
        case 'semana':
            groupByFormat = '%X-%V'; // Agrupar por año y número de semana
            break;
        case 'mes':
            groupByFormat = '%Y-%m'; // Agrupar por año y mes
            break;
        case 'año':
            groupByFormat = '%Y'; // Agrupar por año
            break;
        default:
            return res.status(400).json({ mensaje: "Período no válido." });
    }

    const query = `
        SELECT
            DATE_FORMAT(t.fecha_transaccion, ?) AS periodo,
            c.tipo_categoria AS tipo,
            SUM(t.monto_transaccion) AS total
        FROM transacciones t
        JOIN categorias c ON t.id_categoria = c.id_categoria
        JOIN cuentas cu ON t.id_cuenta = cu.id_cuenta
        WHERE cu.id_usuario = ?
        GROUP BY periodo, tipo
        ORDER BY periodo;
    `;

    conexion.query(query, [groupByFormat, idUsuario], (error, resultados) => {
        if (error) {
            console.error("Error en estadísticas:", error.message);
            return res.status(500).json({ mensaje: "Error al generar estadísticas." });
        }
        res.status(200).json({ resumen: resultados });
    });
});

// OBTENER TODOS LOS PAGOS HABITUALES DE UN USUARIO
app.get("/pagos_habituales/:idUsuario", (req, res) => {
    const { idUsuario } = req.params;
    // La consulta ahora ordena por fecha_inicio, ya que fecha_proximo_pago no existe.
    const query = `
        SELECT p.*, c.nombre_cuenta AS nombre_cuenta, cat.nombre_categoria AS nombre_categoria
        FROM pagos_habituales p
        JOIN cuentas c ON p.id_cuenta_origen = c.id_cuenta
        JOIN categorias cat ON p.id_categoria = cat.id_categoria
        WHERE p.id_usuario = ?
        ORDER BY p.fecha_inicio ASC
    `;
    conexion.query(query, [idUsuario], (error, resultados) => {
        if (error) {
            console.error("Error al obtener pagos habituales:", error.message);
            return res.status(500).json({ mensaje: "Error al obtener los pagos habituales." });
        }
        res.status(200).json({ pagosHabituales: resultados });
    });
});

// AÑADIR UN NUEVO PAGO HABITUAL
app.post("/pagos_habituales/agregar", (req, res) => {
    // Tomamos solo los campos que existen en la nueva tabla.
    const pago = {
        id_usuario: req.body.id_usuario,
        id_cuenta_origen: req.body.id_cuenta_origen,
        id_categoria: req.body.id_categoria,
        nombre_pago: req.body.nombre_pago,
        monto_pago: req.body.monto_pago,
        frecuencia: req.body.frecuencia,
        fecha_inicio: req.body.fecha_inicio
    };

    // Validamos los datos recibidos.
    if (!pago.id_usuario || !pago.id_cuenta_origen || !pago.id_categoria || !pago.nombre_pago || !pago.monto_pago || !pago.frecuencia || !pago.fecha_inicio) {
        return res.status(400).json({ mensaje: "Faltan datos obligatorios para crear el pago habitual." });
    }

    const query = 'INSERT INTO pagos_habituales SET ?';
    conexion.query(query, pago, (error, resultado) => {
        if (error) {
            console.error("Error al crear pago habitual:", error.message);
            return res.status(500).json({ mensaje: "Error al crear el pago habitual." });
        }
        res.status(201).json({ mensaje: "Pago habitual creado con éxito.", id: resultado.insertId });
    });
});

// ELIMINAR UN PAGO HABITUAL (Sin cambios, ya era correcto)
app.delete("/pagos_habituales/eliminar/:id", (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM pagos_habituales WHERE id_pago_habitual = ?';
    conexion.query(query, [id], (error, resultado) => {
        if (error) {
            console.error("Error al eliminar pago habitual:", error.message);
            return res.status(500).json({ mensaje: "Error al eliminar." });
        }
        if (resultado.affectedRows === 0) {
            return res.status(404).json({ mensaje: "Pago habitual no encontrado." });
        }
        res.status(200).json({ mensaje: "Pago habitual eliminado." });
    });
});